#ifndef __IOI2C_H
#define __IOI2C_H
#include "stm32l0xx_hal.h"


#define I2C_SCL_PIN					GPIO_PIN_8
#define I2C_SCL_PORT				GPIOB

#define I2C_SDA_PIN					GPIO_PIN_9
#define I2C_SDA_PORT				GPIOB

#define EN_SDA_RCC					__GPIOB_CLK_ENABLE();
#define EN_SCL_RCC					__GPIOB_CLK_ENABLE();

//IO��������	 
#define IIC_SCL(value)    			HAL_GPIO_WritePin(I2C_SCL_PORT,I2C_SCL_PIN,value)//PAout(5) //SCL
#define IIC_SDA(value)    			HAL_GPIO_WritePin(I2C_SDA_PORT,I2C_SDA_PIN,value)//PAout(4) //SDA	 
#define READ_SDA  					HAL_GPIO_ReadPin(I2C_SDA_PORT,I2C_SDA_PIN) //PAin(4)  //����SDA 

//��ʼ��ģ��I2C��IO��
extern void IOIIC_Init(void);

//I2C ��һ���ֽ�
extern uint8_t I2C_ReadOneByte(uint8_t I2C_Addr,uint8_t addr);

//I2C дһ���ֽ�
extern uint8_t I2C_WriteOneByte(uint8_t dev, uint8_t reg, uint8_t data);

//I2C ������ֽ�
extern uint8_t IICreadBytes(uint8_t dev, uint8_t reg, uint8_t length, uint8_t *data);

//I2C д����ֽ�
extern uint8_t IICwriteBytes(uint8_t dev, uint8_t reg, uint8_t length, uint8_t* data);

#endif

//------------------End of File----------------------------
