var group___core___register__gr =
[
    [ "__disable_fault_irq", "group___core___register__gr.html#ga9d174f979b2f76fdb3228a9b338fd939", null ],
    [ "__disable_irq", "group___core___register__gr.html#gaeb8e5f7564a8ea23678fe3c987b04013", null ],
    [ "__enable_fault_irq", "group___core___register__gr.html#ga6575d37863cec5d334864f93b5b783bf", null ],
    [ "__enable_irq", "group___core___register__gr.html#ga0f98dfbd252b89d12564472dbeba9c27", null ],
    [ "__get_APSR", "group___core___register__gr.html#ga811c0012221ee918a75111ca84c4d5e7", null ],
    [ "__get_BASEPRI", "group___core___register__gr.html#ga32da759f46e52c95bcfbde5012260667", null ],
    [ "__get_CONTROL", "group___core___register__gr.html#ga963cf236b73219ce78e965deb01b81a7", null ],
    [ "__get_FAULTMASK", "group___core___register__gr.html#gaa78e4e6bf619a65e9f01b4af13fed3a8", null ],
    [ "__get_FPSCR", "group___core___register__gr.html#gad6d7eca9ddd1d9072dd7b020cfe64905", null ],
    [ "__get_IPSR", "group___core___register__gr.html#ga2c32fc5c7f8f07fb3d436c6f6fe4e8c8", null ],
    [ "__get_MSP", "group___core___register__gr.html#gab898559392ba027814e5bbb5a98b38d2", null ],
    [ "__get_PRIMASK", "group___core___register__gr.html#ga799b5d9a2ae75e459264c8512c7c0e02", null ],
    [ "__get_PSP", "group___core___register__gr.html#ga914dfa8eff7ca53380dd54cf1d8bebd9", null ],
    [ "__get_xPSR", "group___core___register__gr.html#ga732e08184154f44a617963cc65ff95bd", null ],
    [ "__set_BASEPRI", "group___core___register__gr.html#ga360c73eb7ffb16088556f9278953b882", null ],
    [ "__set_CONTROL", "group___core___register__gr.html#gac64d37e7ff9de06437f9fb94bbab8b6c", null ],
    [ "__set_FAULTMASK", "group___core___register__gr.html#gaa5587cc09031053a40a35c14ec36078a", null ],
    [ "__set_FPSCR", "group___core___register__gr.html#ga6f26bd75ca7e3247f27b272acc10536b", null ],
    [ "__set_MSP", "group___core___register__gr.html#ga0bf9564ebc1613a8faba014275dac2a4", null ],
    [ "__set_PRIMASK", "group___core___register__gr.html#ga70b4e1a6c1c86eb913fb9d6e8400156f", null ],
    [ "__set_PSP", "group___core___register__gr.html#ga48e5853f417e17a8a65080f6a605b743", null ]
];