var searchData=
[
  ['tpriority',['tpriority',['../structos_thread_def__t.html#a15da8f23c6fe684b70a73646ada685e7',1,'osThreadDef_t']]]
];
