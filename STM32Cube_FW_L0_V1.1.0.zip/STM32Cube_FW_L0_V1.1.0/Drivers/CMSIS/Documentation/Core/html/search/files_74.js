var searchData=
[
  ['template_2etxt',['Template.txt',['../_template_8txt.html',1,'']]]
];
